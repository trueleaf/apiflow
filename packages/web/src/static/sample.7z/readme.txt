This is a sample 7Z file created for testing purposes.
It contains several test files.