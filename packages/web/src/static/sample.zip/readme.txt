This is a sample ZIP file created for testing purposes.
It contains several test files.